data:extend(
	{
		-- buttons main with +3*2 border = 36x36
		{
			type = "sprite",
			name = "sprite_spbook_main",
			filename = "__SpaceBook__/graphics/but-main.png",
			width = 30,
			height = 30,
		},
		{
			type = "sprite",
			name = "sprite_spbook_main_shd",
			filename = "__SpaceBook__/graphics/but-main-shd.png",
			width = 30,
			height = 30,
		},
		{
			type = "sprite",
			name = "sprite_spbook_main_hum",
			filename = "__SpaceBook__/graphics/but-main-hum.png",
			width = 30,
			height = 30,
		},
		{
			type = "sprite",
			name = "sprite_spbook_main_ava",
			filename = "__SpaceBook__/graphics/but-main-ava.png",
			width = 30,
			height = 30,
		},
		{
			type = "sprite",
			name = "sprite_spbook_main_tel",
			filename = "__SpaceBook__/graphics/but-main-tel.png",
			width = 30,
			height = 30,
		},
		-- buttons stances with +3*2 border = 28x30
		{
			type = "sprite",
			name = "sprite_spbook_neutral",
			filename = "__SpaceBook__/graphics/but-neutral.png",
			width = 22,
			height = 24,
		},
		{
			type = "sprite",
			name = "sprite_spbook_friend",
			filename = "__SpaceBook__/graphics/but-friend.png",
			width = 22,
			height = 24,
		},
		{
			type = "sprite",
			name = "sprite_spbook_friend2",
			filename = "__SpaceBook__/graphics/but-friend2.png",
			width = 22,
			height = 24,
		},
		{
			type = "sprite",
			name = "sprite_spbook_enemy",
			filename = "__SpaceBook__/graphics/but-enemy.png",
			width = 22,
			height = 24,
		},
		{
			type = "sprite",
			name = "sprite_spbook_enemy2",
			filename = "__SpaceBook__/graphics/but-enemy2.png",
			width = 22,
			height = 24,
		},
		-- buttons conn with no border = 28x30
		{
			type = "sprite",
			name = "sprite_spbook_conn",
			filename = "__SpaceBook__/graphics/but-conn.png",
			width = 28,
			height = 30,
		},
		{
			type = "sprite",
			name = "sprite_spbook_deco",
			filename = "__SpaceBook__/graphics/but-deco.png",
			width = 28,
			height = 30,
		},
		-- buttons shield with no border = 28x30
		{
			type = "sprite",
			name = "sprite_spbook_shd_on",
			filename = "__SpaceBook__/graphics/but-shd-on.png",
			width = 28,
			height = 30,
		},
		{
			type = "sprite",
			name = "sprite_spbook_shd_off",
			filename = "__SpaceBook__/graphics/but-shd-off.png",
			width = 28,
			height = 30,
		},
		{
			type = "sprite",
			name = "sprite_spbook_shd_deco",
			filename = "__SpaceBook__/graphics/but-shd-deco.png",
			width = 28,
			height = 30,
		},
		-- buttons infods with no border = 28x30
		{
			type = "sprite",
			name = "sprite_spbook_info_none",
			filename = "__SpaceBook__/graphics/but-info-none.png",
			width = 28,
			height = 30,
		},
		{
			type = "sprite",
			name = "sprite_spbook_info_error",
			filename = "__SpaceBook__/graphics/but-info-error.png",
			width = 28,
			height = 30,
		},
		{
			type = "sprite",
			name = "sprite_spbook_info_ok",
			filename = "__SpaceBook__/graphics/but-info-ok.png",
			width = 28,
			height = 30,
		},
		{
			type = "sprite",
			name = "sprite_spbook_info_confirm",
			filename = "__SpaceBook__/graphics/but-info-confirm.png",
			width = 28,
			height = 30,
		},
		{
			type = "sprite",
			name = "sprite_spbook_too_delresources",
			filename = "__SpaceBook__/graphics/but-delresources.png",
			width = 32,
			height = 32,
		},
		{
			type = "sprite",
			name = "sprite_spbook_too_deltrees",
			filename = "__SpaceBook__/graphics/but-deltrees.png",
			width = 32,
			height = 32,
		},
		{
			type = "sprite",
			name = "sprite_spbook_too_killaliens",
			filename = "__SpaceBook__/graphics/but-killaliens.png",
			width = 32,
			height = 32,
		},
	}
)		

default_gui.spbook_sprite_main_style = 
{
	type="button_style",
	parent="button_style",
	top_padding = 0,
	right_padding = 0,
	bottom_padding = 0,
	left_padding = 0,
	width = 36,
	height = 36,
	scalable = false,
}

default_gui.spbook_sprite_butin_style = 
{
	type="button_style",
	parent="button_style",
	top_padding = 0,
	right_padding = 0,
	bottom_padding = 0,
	left_padding = 0,
	width = 28,
	height = 30,
	scalable = false,
}

default_gui.spbook_sprite_icon_style = 
{
	type="button_style",
	parent="button_style",
	top_padding = 0,
	right_padding = 0,
	bottom_padding = 0,
	left_padding = 0,
	width = 28,
	height = 30,
	scalable = false,
	default_graphical_set = extract_monolith("__SpaceBook__/graphics/gui.png", 0, 0, 28, 30),
	hovered_graphical_set = extract_monolith("__SpaceBook__/graphics/gui.png", 28, 0, 28, 30),
	clicked_graphical_set = extract_monolith("__SpaceBook__/graphics/gui.png", 56, 0, 28, 30),
	disabled_graphical_set = extract_monolith("__SpaceBook__/graphics/gui.png", 0, 0, 28, 30),
}


default_gui.spbook_button_style = 
{
	type="button_style",
	parent="button_style",
	font="spbook_font_bold",
	align = "center",
	height = 30,
	top_padding = 0,
	right_padding = spacing_right,
	bottom_padding = 0,
	left_padding = spacing_right,
	scalable = false,
	left_click_sound =
	{
		{
		  filename = "__core__/sound/gui-click.ogg",
		  volume = 1
		}
	},
}

default_gui.spbook_button_small_style = 
{
	type="button_style",
	parent="spbook_button_style",
	font="spbook_font_small",
	height = 24,
}

default_gui.spbook_button_xy_style = 
{
	type="button_style",
	parent="spbook_button_style",
	font="spbook_font_xy",
	minimal_width = 60,
}

default_gui.spbook_button_name_style = 
{
	type="button_style",
	parent="spbook_button_style",
	font="spbook_font_name",
	align = "left",
	minimal_width = 100,
}

